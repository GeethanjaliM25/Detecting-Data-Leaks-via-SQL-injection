# backend/models.py
import sqlite3
import os
from datetime import datetime

DB_PATH = os.getenv("DB_PATH", "backend/demo.db")

def get_conn():
    os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_conn()
    cur = conn.cursor()
    # users table (demo data for vulnerable endpoint)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT
    )
    """)
    # incidents table
    cur.execute("""
    CREATE TABLE IF NOT EXISTS incidents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT,
        log_line TEXT,
        pattern TEXT,
        severity TEXT,
        evidence_key TEXT,
        uploaded_at TEXT,
        status TEXT DEFAULT 'New',
        notes TEXT
    )
    """)
    # seed demo users if empty
    cur.execute("SELECT COUNT(*) as c FROM users")
    if cur.fetchone()["c"] == 0:
        cur.executemany("INSERT INTO users (name,email) VALUES (?,?)",
                        [("Alice","alice@example.com"),("Bob","bob@example.com")])
    conn.commit()
    conn.close()

def register_incident(log_line, pattern, severity, evidence_key, uploaded_at):
    conn = get_conn()
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    cur.execute("""
      INSERT INTO incidents (created_at, log_line, pattern, severity, evidence_key, uploaded_at)
      VALUES (?,?,?,?,?,?)
    """, (now, log_line, pattern, severity, evidence_key, uploaded_at))
    conn.commit()
    inc_id = cur.lastrowid
    conn.close()
    return inc_id

def list_incidents():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM incidents ORDER BY created_at DESC")
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return rows

def get_incident(inc_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM incidents WHERE id = ?", (inc_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

def update_incident(inc_id, status=None, notes=None):
    conn = get_conn()
    cur = conn.cursor()
    if status:
        cur.execute("UPDATE incidents SET status=? WHERE id=?", (status, inc_id))
    if notes:
        cur.execute("UPDATE incidents SET notes = COALESCE(notes,'') || ? WHERE id=?", ("\n" + notes, inc_id))
    conn.commit()
    conn.close()
