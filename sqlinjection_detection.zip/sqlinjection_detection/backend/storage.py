# backend/storage.py
import os
import boto3
from botocore.client import Config

AWS_ENDPOINT_URL = os.getenv("AWS_ENDPOINT_URL")
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
B2_BUCKET = os.getenv("B2_BUCKET")

def get_s3_client():
    s3 = boto3.client(
        "s3",
        endpoint_url=AWS_ENDPOINT_URL,
        aws_access_key_id=AWS_ACCESS_KEY_ID,
        aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        config=Config(signature_version="s3v4")
    )
    return s3

def upload_text(key, text, content_type="text/plain"):
    s3 = get_s3_client()
    s3.put_object(Bucket=B2_BUCKET, Key=key, Body=text.encode("utf-8"), ContentType=content_type)
    return key

def get_object_url(key):
    # Backblaze supports object URLs at endpoint/bucket/key
    endpoint = AWS_ENDPOINT_URL.rstrip("/")
    return f"{endpoint}/{B2_BUCKET}/{key}"
