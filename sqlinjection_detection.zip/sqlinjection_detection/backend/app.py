from flask import Flask, request, jsonify
from flask_cors import CORS
import re

app = Flask(__name__)
CORS(app)

# Proper SQL injection patterns
patterns = {
    "Union Attack": r"(?i)\bUNION\b",
    "OR True Condition": r"(?i)\bOR\b\s+1=1",
    "Comment Attack": r"--|#",
    "Drop Table": r"(?i)\bDROP\b",
    "Information Schema Access": r"(?i)INFORMATION_SCHEMA",
    "Time Delay Attack": r"(?i)WAITFOR\s+DELAY",
    "Multi Query Injection": r";\s*(SELECT|INSERT|UPDATE|DELETE)"
}

def detect_injection(query):
    issues = []

    for attack, pattern in patterns.items():
        if re.search(pattern, query):
            issues.append(attack)

    if len(issues) == 0:
        return {"safe": True, "issues": []}
    else:
        return {"safe": False, "issues": issues}


@app.route("/detect", methods=["POST"])
def detect():
    data = request.get_json()
    query = data.get("query", "")

    result = detect_injection(query)
    return jsonify(result)


@app.route("/", methods=["GET"])
def home():
    return "SQL Injection Detector API is running!"

if __name__ == "__main__":
    app.run(debug=True)
