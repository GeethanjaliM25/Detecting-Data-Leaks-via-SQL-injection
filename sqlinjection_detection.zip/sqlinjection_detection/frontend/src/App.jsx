import { useState } from "react";
import "./App.css";

function App() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState("");

  const checkQuery = async () => {
    try {
      const res = await fetch("http://127.0.0.1:5000/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query })
      });

      const data = await res.json();
      setResult(data.message);
    } catch (error) {
      setResult("❌ Backend not reachable!");
    }
  };

  return (
    <div className="container">
      <h2>SQL Injection Checker</h2>

      <textarea
        placeholder="Enter SQL query..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        rows={7}
      />

      <button onClick={checkQuery}>Check Query</button>

      <div className="output">{result}</div>
    </div>
  );
}

export default App;
