# Detecting Data Leaks via SQL Injection (Full-Stack Demo)

## Overview
This project demonstrates a safe lab: a vulnerable Flask endpoint, a detector that scans logs for SQL injection patterns, uploads evidence to Backblaze B2, and a React admin dashboard to view incidents.

## Prereqs
- Python 3.10+
- Node.js (if using frontend) / npm
- Backblaze B2 account & scoped App Key (use S3-compatible App Key)
- (optional) Docker & docker-compose

## Quick start (local)
1. Copy `.env.example` to `.env` and fill keys.
2. Backend:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r backend/requirements.txt
   cd backend
   python app.py
