# detector/detector.py
import os, time, re, json
from dotenv import load_dotenv
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from uploader_boto3 import upload_text
import requests
from datetime import datetime

load_dotenv(dotenv_path="../.env")

LOG_FILE = os.getenv("LOG_FILE", "backend/logs/access.log")
SCAN_INTERVAL = int(os.getenv("DETECTOR_SCAN_INTERVAL", 10))
BACKEND_REGISTER = os.getenv("BACKEND_REGISTER", "http://localhost:5000/api/incidents/register")
PATTERNS = [
    re.compile(r"(?i)\bOR\b\s+['\"]?1['\"]?\s*=\s*['\"]?1"),
    re.compile(r"--"),
    re.compile(r";\s*DROP\b", re.I),
    re.compile(r"UNION\b\s+SELECT", re.I),
]

# track offsets to avoid duplicate processing
OFFSET_FILE = ".detector_offset"

def read_offset():
    if not os.path.exists(OFFSET_FILE): return 0
    try:
        with open(OFFSET_FILE,"r") as f:
            return int(f.read().strip())
    except:
        return 0

def write_offset(val):
    with open(OFFSET_FILE,"w") as f:
        f.write(str(val))

def scan_new_lines():
    if not os.path.exists(LOG_FILE):
        return
    offset = read_offset()
    with open(LOG_FILE,"r",encoding="utf-8") as f:
        f.seek(offset)
        new = f.read()
        new_offset = f.tell()
    if not new:
        return
    lines = new.splitlines()
    for i, line in enumerate(lines):
        for p in PATTERNS:
            if p.search(line):
                # suspicious -> upload evidence to B2
                ts = datetime.utcnow().strftime("%Y%m%d%H%M%S")
                key = f"evidence/susp_{ts}_{i}.log"
                body = f"pattern={p.pattern}\n{line}"
                try:
                    upload_text(key, body)
                    # register with backend
                    payload = {
                        "log_line": line,
                        "pattern": p.pattern,
                        "severity": "MEDIUM",
                        "evidence_key": key,
                        "uploaded_at": datetime.utcnow().isoformat()
                    }
                    try:
                        requests.post(BACKEND_REGISTER, json=payload, timeout=5)
                    except Exception as e:
                        print("Warning: backend register failed:", e)
                    print("Uploaded evidence:", key)
                except Exception as e:
                    print("Upload failed:", e)
    write_offset(new_offset)

class LogHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path.endswith("access.log"):
            scan_new_lines()

if __name__ == "__main__":
    # initial scan
    scan_new_lines()
    observer = Observer()
    # watch the backend logs directory
    logs_dir = os.path.dirname(LOG_FILE) or "."
    observer.schedule(LogHandler(), logs_dir, recursive=False)
    observer.start()
    try:
        while True:
            time.sleep(SCAN_INTERVAL)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
